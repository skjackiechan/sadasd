import { cn } from "@/lib/utils";

/**
 * Decorative background chrome keyed off the active game id. Renders
 * non-interactive, low-contrast atmosphere behind the details pane.
 *
 * The point isn't to be loud — it's to give each game a faint visual
 * signature so muscle memory builds ("the one with the bat in the
 * corner"). Opacity is kept very low (3–6%) so it doesn't fight the
 * UI; a subtle radial wash brightens slightly when `attached` so the
 * room "lights up" when the trainer is live.
 */
export function GameAtmosphere({
  gameId,
  attached,
}: {
  gameId: string;
  attached: boolean;
}) {
  const decor = pickDecor(gameId);
  if (!decor) return null;

  return (
    <div
      aria-hidden
      data-slot="game-atmosphere"
      className="pointer-events-none absolute inset-0 overflow-hidden"
    >
      {/* Signal wash — diffuse radial that pools light into the
          bottom-right where the silhouette sits. Brightens when the
          trainer attaches. */}
      <div
        className={cn(
          "absolute -bottom-32 -right-24 h-[420px] w-[420px] rounded-full blur-3xl transition-opacity duration-700",
          attached ? "opacity-100" : "opacity-50",
        )}
        style={{
          background: `radial-gradient(circle at center,
            color-mix(in oklch, ${decor.signal} ${attached ? 22 : 10}%, transparent),
            transparent 65%)`,
        }}
      />
      {/* Silhouette itself — flat fill at very low alpha. Sits in
          the bottom-right so the eye finds it but it never competes
          with the feature list. */}
      <div
        className={cn(
          "absolute bottom-6 right-6 transition-opacity duration-700",
          attached ? "opacity-[0.085]" : "opacity-[0.05]",
        )}
        style={{ color: "var(--color-foreground)" }}
      >
        <decor.Mark />
      </div>
    </div>
  );
}

type Decor = {
  signal: string;
  Mark: React.FC;
};

function pickDecor(gameId: string): Decor | null {
  // Batman family — covers `batman-lod` today, future titles like
  // `batman-arkham-*` slot in via the prefix. Signal hue is a warm
  // amber that reads as the bat-signal beam.
  if (gameId.startsWith("batman")) {
    return {
      signal: "oklch(78% 0.16 78)",
      Mark: BatMark,
    };
  }
  return null;
}

/**
 * Bat silhouette — classic spread-wings shape with a small head notch
 * between the wings. Rendered as `currentColor` so the parent in
 * `GameAtmosphere` can drive the opacity / hue and the dark + light
 * themes pick up the right contrast automatically.
 */
function BatMark() {
  return (
    <svg
      width="280"
      height="280"
      viewBox="0 0 276 276"
      fill="currentColor"
      xmlns="http://www.w3.org/2000/svg"
      aria-hidden
    >
      <path
        d="M247.064,75.156c-19.134-13.736-40.911-13.342-40.911-13.342
           c8.035,2.729,14.787,12.377,14.87,20.493c0.083,8.119-7.709,16.076-23.306,23.633c-15.592,7.554-33.198,5.298-35.691,3.367
           c-2.487-1.927-2.004-5.453-3.771-12.616c-1.77-7.152-9.785-13.109-9.785-13.109c1.91,3.09,3.199,9.696,3.339,11.197
           c0.174,1.913,0.044,4.087-1.9,2.862c-3.048-1.912-8.605-2.862-11.903-2.862s-8.856,0.95-11.91,2.862
           c-1.947,1.225-2.077-0.949-1.907-2.862c0.14-1.5,1.434-8.101,3.34-11.197c0,0-8.014,5.958-9.781,13.109
           c-1.765,7.163-1.287,10.688-3.78,12.616c-2.488,1.936-20.09,4.185-35.681-3.367c-15.593-7.557-23.395-15.515-23.312-23.633
           c0.078-8.116,6.829-17.761,14.87-20.493c0,0-21.778-0.4-40.912,13.342C9.809,88.893-0.239,109.8,0.004,122.981
           c0.24,13.179,3.131,40.658,25.236,58.987c0,0-2.354-15.447,1.699-24.744c4.051-9.296,8.819-12.869,15.971-12.869
           c0,0-0.95,9.303,5.725,21.929c6.673,12.632,15.965,22.407,15.965,22.407s6.678-28.844,31.703-30.511
           c25.021-1.672,41.689,55.968,41.7,56.004c0.01-0.036,16.676-57.676,41.696-56.004c25.03,1.669,31.699,30.511,31.699,30.511
           s9.297-9.771,15.972-22.407c6.674-12.626,5.729-21.929,5.729-21.929c7.15,0,11.91,3.579,15.965,12.869
           c4.047,9.297,1.694,24.744,1.694,24.744c22.1-18.329,24.993-45.811,25.237-58.987C276.239,109.8,266.194,88.894,247.064,75.156z"
      />
    </svg>
  );
}
