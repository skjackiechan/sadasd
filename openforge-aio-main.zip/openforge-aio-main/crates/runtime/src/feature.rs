//! `Feature` trait + `DeclarativeFeature` engine + `Tier`.

use std::collections::HashMap;

use openforge_core::{Ctx, Pattern, Result as CoreResult, ctx::read_pointer};
use parking_lot::Mutex;
use serde::{Deserialize, Serialize};

use crate::engines::ue5;
use crate::error::{RuntimeError, RuntimeResult};
use crate::signature::{
    ControlSpec, HeapScanSpec, HeapValidatorSpec, ReflectionSpec, SignatureSpec, WriteSpec,
    parse_hex_payload,
};
use crate::value::{Value, ValueKind, ValueRange};

pub type Tier = String;

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum WriteStrategyKind {
    OneShot,
    Freeze,
    CodePatch,
}

#[derive(Debug, Clone, Serialize)]
pub struct FeatureMeta {
    pub id: String,
    pub display_name: String,
    /// Player-facing one-liner. Distinct from `description`, which is the
    /// long technical write-up shown only behind an info icon.
    pub tagline: Option<String>,
    pub description: Option<String>,
    pub icon: Option<String>,
    /// Optional CSS color for the icon stroke. Passed through verbatim to
    /// the frontend; `None` falls back to a tier-derived hue.
    pub icon_color: Option<String>,
    pub tier: Tier,
    /// Top-level UI category — `"trainer"` (cheats) or `"mod"` (extras).
    /// Drives the Trainer/Mods top tab split in the game details pane.
    pub category: String,
    pub kind: ValueKind,
    pub range: ValueRange,
    pub strategy: WriteStrategyKind,
    pub control: Option<ControlSpec>,
}

#[derive(Debug, Clone, Copy, Serialize)]
pub struct PreflightCheck {
    pub id: &'static str,
    pub ok: bool,
}

#[derive(Debug, Clone, Serialize)]
pub struct PreflightReport {
    pub checks: Vec<PreflightCheck>,
}

impl PreflightReport {
    pub fn ok() -> Self {
        Self { checks: Vec::new() }
    }

    pub fn all_ok(&self) -> bool {
        self.checks.iter().all(|c| c.ok)
    }
}

/// Every cheat in OpenForge implements this trait. Most are
/// [`DeclarativeFeature`] (driven entirely by a signature TOML). The trait is
/// kept open so custom Rust impls can handle the rare cases declarative can't
/// (bitfields, atomic multi-writes, gameplay-state-aware behavior).
pub trait Feature: Send + Sync + 'static {
    fn id(&self) -> &str;
    fn display_name(&self) -> &str;
    fn tagline(&self) -> Option<&str> {
        None
    }
    fn description(&self) -> Option<&str> {
        None
    }
    fn icon(&self) -> Option<&str> {
        None
    }
    /// CSS color for the icon stroke. `None` defers to the frontend's
    /// tier-derived fallback. Set this from a signature TOML
    /// (`[meta] icon_color = "..."`) when the tier's default hue doesn't
    /// fit the feature.
    fn icon_color(&self) -> Option<&str> {
        None
    }
    fn control(&self) -> Option<&ControlSpec> {
        None
    }
    /// For an `engine_action` feature, the `(action, options_action)` ids the
    /// app dispatches on (`invoke_feature_action` / `feature_options`). `None`
    /// for every memory-bound strategy.
    fn engine_action(&self) -> Option<(&str, Option<&str>)> {
        None
    }
    fn tier(&self) -> &str {
        "general"
    }
    fn kind(&self) -> ValueKind;
    fn range(&self) -> ValueRange {
        ValueRange::default()
    }
    fn write_strategy(&self) -> WriteStrategyKind;
    /// Default freeze cadence in milliseconds. Declarative features override
    /// this from their `[write].interval_ms` field.
    fn freeze_interval_ms(&self) -> u32 {
        250
    }

    /// Optional fixed freeze target. When `Some`, the trainer freezes to
    /// this value instead of capturing the field's current value at toggle
    /// time. Returned as an `f64` so the caller (which knows the feature's
    /// declared `kind()`) can coerce to the right `Value` variant.
    ///
    /// Used by `Infinite Health` (always freeze `bCanBeDamaged` at `false`)
    /// and by future "max-out" lock features where capturing the current
    /// value would defeat the lock's purpose.
    fn freeze_value(&self) -> Option<f64> {
        None
    }

    /// Glacier DLL-freeze only: when `Some(off)`, the per-tick freeze copies the
    /// f32 at `resolved_addr + off` into the freeze target instead of writing a
    /// constant (e.g. current := max). The app routes this through the Glacier
    /// DLL `StartFreeze` op's `source_offset`; UE5 / constant freezes return
    /// `None` and use the normal write path.
    fn freeze_copy_offset(&self) -> Option<i64> {
        None
    }

    fn resolve(&self, ctx: &dyn Ctx) -> CoreResult<usize>;
    fn read(&self, ctx: &dyn Ctx, addr: usize) -> RuntimeResult<Value>;
    fn write(&self, ctx: &dyn Ctx, addr: usize, v: Value) -> RuntimeResult<()>;

    /// Snapshot the current bytes at every address this feature would write
    /// to, so the trainer can restore them later (e.g. when a freeze toggle
    /// is switched off and the user expects "back to default").
    ///
    /// Default reads `kind().size()` bytes at `addr`. Features that write to
    /// more than one address per tick (reflection with `also_write`) override
    /// this to concatenate primary + companion bytes.
    fn snapshot(&self, ctx: &dyn Ctx, addr: usize) -> RuntimeResult<Vec<u8>> {
        let size = self.kind().size();
        let mut buf = vec![0u8; size];
        ctx.read_bytes(addr, &mut buf).map_err(RuntimeError::from)?;
        Ok(buf)
    }

    /// Write a previously-captured `snapshot` back to the same address(es).
    /// Pairs with [`snapshot`]; the byte layout is whatever `snapshot`
    /// returned for the same feature. Default writes the buffer back at
    /// `addr`. Features with companion fields override to dispatch slices to
    /// each address in the same order `snapshot` concatenated them.
    fn restore(&self, ctx: &dyn Ctx, addr: usize, snapshot: &[u8]) -> RuntimeResult<()> {
        // No bytes to restore (e.g. attach happened before the feature
        // resolved, or the implementation manages its own per-instance
        // cache via interior state). No-op rather than issuing an empty
        // write — keeps the IPC layer from objecting to zero-length frames.
        if snapshot.is_empty() {
            return Ok(());
        }
        ctx.write_bytes(addr, snapshot)
            .map_err(RuntimeError::from)?;
        Ok(())
    }

    /// Whether the trainer's background read-probe loop should poll this
    /// feature's value every few seconds. Defaults to `true` — appropriate
    /// for primitive reads (memory loads).
    ///
    /// Override and return `false` for features whose `read()` does heavy
    /// work on the game thread (e.g. SetProgressTags reads dozens of
    /// `GetGameProgressValue` UFunction calls per invocation, which would
    /// stall the game frame if polled). Such features still resolve at
    /// attach time and refresh `status_text` on-demand after writes.
    fn supports_probe(&self) -> bool {
        true
    }

    /// Cheap re-check of a previously-resolved address. Returns `true` if the
    /// address still looks correct — used by the trainer's address cache to
    /// skip a full re-scan on re-attach.
    ///
    /// The default is conservative: assume the cache is stale unless the
    /// feature opts in. `DeclarativeFeature` overrides this to re-run heap
    /// validators (cheap) or to trust AOB hits (always good for the process
    /// lifetime).
    fn quick_check(&self, _ctx: &dyn Ctx, _addr: usize) -> bool {
        false
    }

    fn meta(&self) -> FeatureMeta {
        FeatureMeta {
            id: self.id().to_string(),
            display_name: self.display_name().to_string(),
            tagline: self.tagline().map(str::to_string),
            description: self.description().map(str::to_string),
            icon: self.icon().map(str::to_string),
            icon_color: self.icon_color().map(str::to_string),
            tier: self.tier().to_string(),
            category: self.category().to_string(),
            kind: self.kind(),
            range: self.range(),
            strategy: self.write_strategy(),
            control: self.control().cloned(),
        }
    }

    /// Top-level UI category: `"trainer"` or `"mod"`. Drives the
    /// Trainer/Mods top tab split. Defaults to `"trainer"` for backward
    /// compatibility with legacy signatures.
    fn category(&self) -> &str {
        "trainer"
    }

    /// Optional human-readable status line rendered under the FeatureCard
    /// tagline. Use for features whose state is richer than the single
    /// `Value` returned by `read()` — e.g. "20 / 30 skills unlocked" for
    /// SetProgressTags, or "Inventory: 7 items locked" for future bulk
    /// features. Default: no extra status (UI hides the row).
    ///
    /// May perform IPC; called on-demand (attach + after writes) rather
    /// than on a poll loop. Returning `Err` is fine — the UI just hides
    /// the row in that case.
    fn status_text(&self, _ctx: &dyn Ctx, _addr: usize) -> RuntimeResult<Option<String>> {
        Ok(None)
    }
}

/// Source for a build-time-embedded declarative feature. A game crate's
/// `build.rs` emits a `&[DeclFeatureSrc]` slice containing one entry per
/// `signatures/*.toml`.
#[derive(Debug, Clone, Copy)]
pub struct DeclFeatureSrc {
    pub name: &'static str,
    /// Raw config source text (currently always TOML; the `format` field
    /// records which dialect so a future format can be embedded without
    /// changing this struct's shape).
    pub source: &'static str,
    /// Which config format `source` is written in.
    pub format: crate::format::ConfigFormat,
}

impl DeclFeatureSrc {
    /// Parse this embedded source into a [`DeclarativeFeature`], honoring its
    /// declared [`crate::format::ConfigFormat`].
    pub fn parse(&self) -> RuntimeResult<DeclarativeFeature> {
        DeclarativeFeature::from_source(self.source, self.format)
    }
}

/// A feature whose behavior is entirely described by a parsed [`SignatureSpec`].
///
/// `pattern` is `Some` for AOB-based signatures and `None` for heap-scan
/// signatures (where there's nothing to scan in `.text`).
pub struct DeclarativeFeature {
    pub spec: SignatureSpec,
    pub pattern: Option<Pattern>,
    /// Reflection cache. Populated lazily on the first `resolve()`
    /// for features whose signature carries a `[reflection]` block. The
    /// trainer drops the `DeclarativeFeature` on detach, so cache lifetime
    /// is bounded by the session — exactly when the resolved addresses
    /// remain valid.
    reflection_cache: Mutex<Option<ReflectionCache>>,
    /// Per-instance originals captured by `freeze_for_matching` writes, so
    /// toggle-OFF can restore each touched address to its pre-stamp bytes.
    /// Keyed by absolute write address (object base + field_offset); value is
    /// the bytes that were there before our first write (length = payload
    /// length, e.g. 8 for an FGameplayTag). Captured opportunistically on the
    /// first tick that touches an address; drained on `restore()`.
    freeze_originals: Mutex<HashMap<usize, Vec<u8>>>,
    /// Resolved `AnimMontage` UObject addresses for the
    /// `play_anim_montage_for_matching` strategy, indexed in declaration
    /// order from `montage_names`. Populated lazily on the first tick that
    /// can find them; `None` means resolution hasn't run yet, `Some(vec)`
    /// with empty entries (0) for any names that couldn't be resolved on
    /// that pass — those slots get retried each tick until they fill in.
    /// Cleared on `restore()` so the next attach re-resolves.
    montage_cache: Mutex<Option<Vec<u64>>>,
    /// Monotonic tick counter for the `play_anim_montage_for_matching`
    /// loop. Drives the per-NPC montage rotation (each NPC picks
    /// `(tick + npc_idx) mod N` so neighbours don't dance in lock-step).
    montage_tick: std::sync::atomic::AtomicU64,
}

/// Resolved addresses for one reflection-based feature. Held inside the
/// `DeclarativeFeature` so `write()` can mirror the primary value to any
/// companion (`also_write`) fields without re-querying the DLL each tick.
#[derive(Debug, Clone)]
struct ReflectionCache {
    /// Live UObject we resolved against. Used to detect cache staleness on
    /// subsequent read/write — when the world reloads (level transition,
    /// main-menu round-trip), the old object is freed and a new one takes
    /// its place at a different address. We probe `obj_addr + class_private`
    /// before each access; a mismatch with `class_addr` triggers a re-walk.
    obj_addr: u64,
    /// The cached UObject's UClass pointer. The validity check above
    /// compares this to whatever currently lives at `obj_addr + 0x10`.
    class_addr: u64,
    /// Property offset within the UObject. Stable across game launches
    /// (it's baked into the UClass layout), so cache survives re-resolves
    /// of the same class. Currently captured for forensics + future use
    /// (e.g. recomputing `primary` after a cheap re-find without paying
    /// the property-lookup cost again).
    #[allow(dead_code)]
    primary_offset: u32,
    /// Object addr + primary property offset. Doubles as the root of the
    /// deref chain when `derefs` is non-empty: each write starts here, reads
    /// 8 bytes as the first pointer, then follows `derefs` step by step.
    /// When `derefs` is empty, `resolve()` returns this directly and
    /// `write()` receives it via the trainer's address cache rather than
    /// reading it back from here.
    #[allow(dead_code)]
    primary: usize,
    /// Addresses for each `also_write` property on the same class. The
    /// same coerced value is mirrored here on every `write()`.
    companions: Vec<usize>,
    /// Pointer-deref chain configured via `[[reflection.deref]]` entries.
    /// Each entry walks one pointer hop; the final entry's property is the
    /// value-type field that gets read/written. Empty = no deref (write at
    /// `primary` directly).
    ///
    /// One-hop: Lock Health — PlayerState.PawnPrivate → bCanBeDamaged
    /// (single entry: `bCanBeDamaged`).
    ///
    /// Two-hop: movement mods — PlayerState.PawnPrivate →
    /// Pawn.CharacterMovement → CMC.JumpZVelocity
    /// (entries: `CharacterMovement`, `JumpZVelocity`).
    derefs: Vec<DerefStep>,
}

/// True if `obj` is a live UObject: pointer-aligned, in user space, and its
/// vtable (the pointer at offset 0) lands inside the main module image. Engine
/// and Blueprint UObjects always carry a native C++ vtable in the game image,
/// so a vtable outside it means the slot is freed / mid-construction / not
/// really an object.
///
/// We use this to refuse reads/writes through a deref chain whose intermediate
/// object was reallocated during a world transition. Writing through such a
/// stale chain stamps bytes into freed memory the engine later re-uses and
/// dereferences as a pointer — the observed crash is `c0000005` (access
/// violation) in *game* code (fault module = the game exe), on level / area
/// transitions, right after a synchronized "object reallocated" burst.
fn is_live_uobject(ctx: &dyn Ctx, obj: usize) -> bool {
    if obj < 0x10000 || !obj.is_multiple_of(8) {
        return false;
    }
    let Ok(vtable) = read_pointer(ctx, obj) else {
        return false;
    };
    let m = ctx.main_module();
    let mod_end = m.base.saturating_add(m.size);
    (m.base..mod_end).contains(&vtable)
}

#[derive(Debug, Clone)]
struct DerefStep {
    /// Property name to resolve on whatever class the *previous* pointer
    /// turns out to be. Storing the name (not a resolved offset) is by
    /// design: the same parent property can point to different concrete
    /// subclasses across game sessions or character switches; the per-class
    /// offset cache in `Ue5Session::resolve_property` makes the second
    /// lookup free.
    property_name: String,
    /// Raw byte offset added after the property's resolved offset. Only
    /// meaningful on the final hop — used to reach a primitive inside a
    /// `StructProperty` (e.g. `Health.CurrentValue` at +12 inside
    /// `FGameplayAttributeData`).
    inner_offset: i64,
}

impl DeclarativeFeature {
    /// Parse from `src` in the given [`crate::format::ConfigFormat`], validate,
    /// and build the feature. Format-agnostic entry point; the previous
    /// `from_toml` is now a thin TOML-pinned wrapper around this.
    pub fn from_source(src: &str, fmt: crate::format::ConfigFormat) -> RuntimeResult<Self> {
        let spec = SignatureSpec::parse_with(src, fmt)?;
        spec.validate()?;
        let pattern = match &spec.locator {
            Some(loc) => Some(Pattern::parse(&loc.pattern).map_err(RuntimeError::from)?),
            None => None,
        };
        Ok(Self {
            spec,
            pattern,
            reflection_cache: Mutex::new(None),
            freeze_originals: Mutex::new(HashMap::new()),
            montage_cache: Mutex::new(None),
            montage_tick: std::sync::atomic::AtomicU64::new(0),
        })
    }

    /// Back-compat shim: parse from TOML source. Equivalent to
    /// `from_source(toml, ConfigFormat::Toml)`.
    pub fn from_toml(toml: &str) -> RuntimeResult<Self> {
        Self::from_source(toml, crate::format::ConfigFormat::Toml)
    }

    fn resolve_via_reflection(
        &self,
        ctx: &dyn Ctx,
        ref_spec: &ReflectionSpec,
    ) -> RuntimeResult<usize> {
        let pred = ref_spec.predicate.to_core();
        let (obj_addr, class_addr) = ctx
            .find_uobject(&ref_spec.class_path, &pred)
            .map_err(RuntimeError::from)?
            .ok_or_else(|| RuntimeError::SignatureInvalid {
                feature: self.id().to_string(),
                reason: format!(
                    "reflection: no live UObject of class `{}` (predicate {:?}). \
                     If the game is on the main menu, start a level and retry.",
                    ref_spec.class_path, ref_spec.predicate
                ),
            })?;
        let primary_resolved = ctx
            .resolve_property(class_addr, &ref_spec.property_name)
            .map_err(RuntimeError::from)?
            .ok_or_else(|| RuntimeError::SignatureInvalid {
                feature: self.id().to_string(),
                reason: format!(
                    "reflection: property `{}` not found on class `{}` chain — \
                     check the signature TOML against a `discover` dump",
                    ref_spec.property_name, ref_spec.class_path
                ),
            })?;
        let mut primary_addr = (obj_addr as usize).saturating_add(primary_resolved.offset as usize);
        if ref_spec.deref.is_empty()
            && let Some(offset) = ref_spec.offset
        {
            primary_addr = (primary_addr as i64).wrapping_add(offset) as usize;
        }

        let mut companions: Vec<usize> = Vec::with_capacity(ref_spec.also_write.len());
        for name in &ref_spec.also_write {
            let r = ctx
                .resolve_property(class_addr, name)
                .map_err(RuntimeError::from)?
                .ok_or_else(|| RuntimeError::SignatureInvalid {
                    feature: self.id().to_string(),
                    reason: format!(
                        "reflection: also_write property `{name}` not found on class `{}` chain",
                        ref_spec.class_path
                    ),
                })?;
            companions.push((obj_addr as usize).saturating_add(r.offset as usize));
        }

        let derefs: Vec<DerefStep> = ref_spec
            .deref
            .iter()
            .map(|d| DerefStep {
                property_name: d.property_name.clone(),
                inner_offset: d.inner_offset,
            })
            .collect();

        tracing::info!(
            feature = self.id(),
            class = %ref_spec.class_path,
            obj = format!("0x{:X}", obj_addr),
            primary = format!("0x{:X}", primary_addr),
            companions = companions.len(),
            deref_hops = derefs.len(),
            "reflection resolved"
        );

        *self.reflection_cache.lock() = Some(ReflectionCache {
            obj_addr,
            class_addr,
            primary_offset: primary_resolved.offset,
            primary: primary_addr,
            companions,
            derefs,
        });
        Ok(primary_addr)
    }

    /// Validate the reflection cache and re-resolve from scratch if the
    /// cached UObject is no longer live. Returns the current primary
    /// address — same as the cache's `primary` if validation passed, or a
    /// new one if we had to re-walk after a world transition.
    ///
    /// Validation is a single 8-byte read at `obj_addr + 0x10`
    /// (UObject::ClassPrivate). If it still matches the cached `class_addr`,
    /// the object is alive at the same address and we trust the cache. Any
    /// mismatch — or read failure (unmapped page) — triggers a full
    /// `resolve_via_reflection` call, which updates the cache and returns
    /// the new primary.
    ///
    /// This is the heart of the self-heal: level transitions free the
    /// PlayerState (and its possessed Pawn / CharacterMovement), so the
    /// next freeze-tick or write would otherwise hit a freed object. With
    /// this guard, the trainer transparently re-finds the new instances.
    fn ensure_reflection_fresh(&self, ctx: &dyn Ctx) -> RuntimeResult<usize> {
        let ref_spec =
            self.spec
                .reflection
                .as_ref()
                .ok_or_else(|| RuntimeError::SignatureInvalid {
                    feature: self.id().to_string(),
                    reason: "ensure_reflection_fresh called on non-reflection feature".into(),
                })?;

        let cached = {
            let guard = self.reflection_cache.lock();
            guard
                .as_ref()
                .map(|c| (c.obj_addr, c.class_addr, c.primary))
        };

        if let Some((obj_addr, expected_class, primary)) = cached {
            // Read the class slot. If the read or comparison fails, fall
            // through to re-resolve — never propagate the error here.
            // Also require the object to still be a live UObject (vtable in
            // module): a freed-but-not-yet-overwritten object keeps a stale
            // class pointer that would pass the class match alone, so the
            // vtable check is what actually rejects a mid-transition object
            // before a write lands on it.
            let class_slot = (obj_addr as usize).saturating_add(ctx.uobject_class_offset());
            if is_live_uobject(ctx, obj_addr as usize)
                && let Ok(live_class) = read_pointer(ctx, class_slot)
                && live_class as u64 == expected_class
            {
                return Ok(primary);
            }
            tracing::info!(
                feature = self.id(),
                obj = format!("0x{obj_addr:X}"),
                "reflection cache invalidated (object reallocated) — re-resolving"
            );
        }
        self.resolve_via_reflection(ctx, ref_spec)
    }

    /// Walk the deref chain from `root_ptr_addr` and return the address of
    /// the final value-type field. Called on every `read()`/`write()` for
    /// features with `[[reflection.deref]]` entries.
    ///
    /// The chain is re-walked on every call (no cached intermediate
    /// addresses) because every pointer in it can be reseated — pawn
    /// pointers shift on character switches, component pointers reseat
    /// when components are re-registered, etc. The dereffed objects' class
    /// lookups in `ctx.resolve_property` are cached per UClass inside
    /// `Ue5Session`, so the only real cost per call is N pointer reads +
    /// 1 class-property lookup per hop (HashMap hit after the first walk).
    ///
    /// `derefs` must be non-empty; callers should bypass this and use
    /// `primary` directly when the chain is empty.
    fn resolve_deref_addr(
        &self,
        ctx: &dyn Ctx,
        root_ptr_addr: usize,
        derefs: &[DerefStep],
    ) -> RuntimeResult<usize> {
        debug_assert!(
            !derefs.is_empty(),
            "resolve_deref_addr called with empty chain — caller should write at primary directly"
        );

        // Start by reading the live pointer at the root slot.
        let mut current_ptr_addr = root_ptr_addr;
        for (hop_idx, step) in derefs.iter().enumerate() {
            let target_obj = read_pointer(ctx, current_ptr_addr).map_err(RuntimeError::from)?;
            if target_obj == 0 {
                return Err(RuntimeError::SignatureInvalid {
                    feature: self.id().to_string(),
                    reason: format!(
                        "reflection.deref: null pointer at hop {hop_idx} \
                         (slot 0x{current_ptr_addr:X}) before resolving `{}` — \
                         intermediate sub-object isn't live (typically: no \
                         pawn possessed yet, or component not registered)",
                        step.property_name
                    ),
                });
            }
            // Liveness guard (crash-hardening): confirm this hop's object is a
            // real, live UObject before resolving a property on it or writing
            // through it. During a world transition an intermediate pointer
            // (e.g. PawnPrivate / CharacterMovement) can briefly reseat to a
            // freed or half-constructed object; walking it and stamping a value
            // corrupts game memory and crashes the game in its own code
            // (c0000005). Bail so the caller skips this read/write tick and
            // retries once the world settles.
            if !is_live_uobject(ctx, target_obj) {
                return Err(RuntimeError::SignatureInvalid {
                    feature: self.id().to_string(),
                    reason: format!(
                        "reflection.deref: hop {hop_idx} object 0x{target_obj:X} is not a live \
                         UObject (vtable outside module image) before resolving `{}` — likely \
                         freed mid world-transition; skipping this tick",
                        step.property_name
                    ),
                });
            }
            // Resolve the named property against the dereffed object's
            // actual UClass (read from its UObject header). This handles
            // concrete subclasses without us hard-coding them.
            let class_addr =
                read_pointer(ctx, target_obj.saturating_add(ctx.uobject_class_offset()))
                    .map_err(RuntimeError::from)? as u64;
            let resolved = ctx
                .resolve_property(class_addr, &step.property_name)
                .map_err(RuntimeError::from)?
                .ok_or_else(|| RuntimeError::SignatureInvalid {
                    feature: self.id().to_string(),
                    reason: format!(
                        "reflection.deref: property `{}` not found on dereferenced \
                         object's class at hop {hop_idx} (class_addr=0x{:X})",
                        step.property_name, class_addr
                    ),
                })?;
            let next_addr = target_obj.saturating_add(resolved.offset as usize);
            // Apply per-step `inner_offset` (defaults to 0). The realistic
            // use is on the FINAL hop, where the resolved property is a
            // StructProperty and the caller needs a primitive field inside
            // it (e.g. `Health.CurrentValue` at +12 inside
            // `FGameplayAttributeData`). On intermediate hops the slot is a
            // pointer about to be dereffed by the next iteration; shifting
            // it would point at unrelated memory. We don't forbid that
            // combination here — the cost of being wrong is "next read
            // returns an error," the same surface as a typo in a name.
            current_ptr_addr = (next_addr as i64).wrapping_add(step.inner_offset) as usize;
        }
        // After the final hop, `current_ptr_addr` points at the value-type
        // field (since the last step's resolved property is the value, not
        // another pointer to dereference). For
        // `WriteSpec::CallInstanceUFunction` the caller treats this address
        // as a pointer SLOT and dereferences it one more time to get the
        // call target.
        if let Some(offset) = self.spec.reflection.as_ref().and_then(|r| r.offset) {
            current_ptr_addr = (current_ptr_addr as i64).wrapping_add(offset) as usize;
        }
        Ok(current_ptr_addr)
    }

    /// Find the data-asset, read its outer TArray, extract per-entry
    /// `FGameplayTag` bytes. Shared by `write` (grant) and `read` (count).
    fn extract_progress_tags(
        &self,
        ctx: &dyn Ctx,
        source: &crate::signature::TagSourceSpec,
    ) -> RuntimeResult<Vec<[u8; ue5::SPT_FNAME_SIZE]>> {
        use crate::signature::TagSourceMode;

        // AllUObjectsOfClass: walk GUObjectArray for every live instance
        // of `asset_class`, filter by short-name substring exclude, read
        // the tag property off each instance. Different shape from the
        // single-asset modes below — short-circuit here.
        if let TagSourceMode::AllUObjectsOfClass {
            tag_property_name,
            exclude_name_substrings,
        } = &source.mode
        {
            // Cap reasonably; LotDK ships ~50 outfit metas in a hub.
            const MAX_INSTANCES: u32 = 4096;
            let (matches, _truncated) = ctx
                .find_all_uobjects(
                    &source.asset_class,
                    &openforge_core::Predicate::Any,
                    MAX_INSTANCES,
                )
                .map_err(RuntimeError::from)?;
            if matches.is_empty() {
                return Ok(Vec::new());
            }
            // Resolve the tag property offset once per UClass we see
            // (most instances share one class; cache one-deep).
            let mut tags: Vec<[u8; ue5::SPT_FNAME_SIZE]> = Vec::with_capacity(matches.len());
            let mut last_class: u64 = 0;
            let mut last_offset: u32 = 0;
            let exclude_lc: Vec<String> = exclude_name_substrings
                .iter()
                .map(|s| s.to_ascii_lowercase())
                .collect();
            for m in &matches {
                // Default__ / CDO instances are never the live data; skip.
                if m.fqn.contains("Default__") {
                    continue;
                }
                // Short name = segment after the last '/' or '.'.
                let short = m
                    .fqn
                    .rsplit(['/', '.'])
                    .next()
                    .unwrap_or(&m.fqn)
                    .to_ascii_lowercase();
                if exclude_lc.iter().any(|s| short.contains(s)) {
                    continue;
                }
                let offset = if m.class_addr == last_class && last_class != 0 {
                    last_offset
                } else {
                    let resolved = ctx
                        .resolve_property(m.class_addr, tag_property_name)
                        .map_err(RuntimeError::from)?
                        .ok_or_else(|| RuntimeError::SignatureInvalid {
                            feature: self.id().to_string(),
                            reason: format!(
                                "set_progress_tags (AllUObjectsOfClass): property `{}` \
                                 not on class chain of `{}`",
                                tag_property_name, source.asset_class
                            ),
                        })?;
                    last_class = m.class_addr;
                    last_offset = resolved.offset;
                    resolved.offset
                };
                let tag_addr = (m.obj_addr as usize).wrapping_add(offset as usize);
                let mut tag = [0u8; ue5::SPT_FNAME_SIZE];
                if ctx.read_bytes(tag_addr, &mut tag).is_ok() {
                    tags.push(tag);
                }
            }
            tracing::debug!(
                feature = self.id(),
                class = source.asset_class,
                scanned = matches.len(),
                kept = tags.len(),
                "extract_progress_tags: AllUObjectsOfClass walk"
            );
            return Ok(tags);
        }

        let (asset_addr, _) = ctx
            .find_uobject(&source.asset_class, &source.predicate.to_core())
            .map_err(RuntimeError::from)?
            .ok_or_else(|| RuntimeError::SignatureInvalid {
                feature: self.id().to_string(),
                reason: format!(
                    "set_progress_tags: no live {} matching {:?}",
                    source.asset_class, source.predicate
                ),
            })?;
        let asset_addr = asset_addr as usize;

        let (array_offset, entry_stride) = match source.mode {
            TagSourceMode::Definitions => (ue5::SPT_DEFS_ARRAY_OFFSET, ue5::SPT_DEF_ENTRY_STRIDE),
            TagSourceMode::RulesValues => (ue5::SPT_RULES_ARRAY_OFFSET, ue5::SPT_RULE_STRIDE),
            TagSourceMode::AllUObjectsOfClass { .. } => unreachable!("handled above"),
        };

        let mut header = [0u8; 16];
        ctx.read_bytes(asset_addr + array_offset as usize, &mut header)
            .map_err(RuntimeError::from)?;
        let data_ptr = u64::from_le_bytes(header[0..8].try_into().unwrap());
        let num = i32::from_le_bytes(header[8..12].try_into().unwrap());
        if data_ptr == 0 || num <= 0 {
            return Ok(Vec::new());
        }
        let num = num as usize;

        let mut body = vec![0u8; num * entry_stride];
        ctx.read_bytes(data_ptr as usize, &mut body)
            .map_err(RuntimeError::from)?;

        let mut tags: Vec<[u8; ue5::SPT_FNAME_SIZE]> = Vec::with_capacity(num);
        match source.mode {
            TagSourceMode::Definitions => {
                for i in 0..num {
                    let off = i * ue5::SPT_DEF_ENTRY_STRIDE + ue5::SPT_DEF_ENTRY_DATA_PTR_OFFSET;
                    let data_ptr = u64::from_le_bytes(body[off..off + 8].try_into().unwrap());
                    if data_ptr == 0 {
                        tags.push([0u8; ue5::SPT_FNAME_SIZE]);
                        continue;
                    }
                    let mut tag = [0u8; ue5::SPT_FNAME_SIZE];
                    ctx.read_bytes(
                        data_ptr as usize + ue5::SPT_DEF_INSTANCE_TAG_OFFSET,
                        &mut tag,
                    )
                    .map_err(RuntimeError::from)?;
                    tags.push(tag);
                }
            }
            TagSourceMode::RulesValues => {
                for i in 0..num {
                    let vh = i * ue5::SPT_RULE_STRIDE + ue5::SPT_RULE_VALUES_OFFSET;
                    let values_data_ptr = u64::from_le_bytes(body[vh..vh + 8].try_into().unwrap());
                    let values_num = i32::from_le_bytes(body[vh + 8..vh + 12].try_into().unwrap());
                    if values_data_ptr == 0 || values_num <= 0 {
                        tags.push([0u8; ue5::SPT_FNAME_SIZE]);
                        continue;
                    }
                    let mut tag = [0u8; ue5::SPT_FNAME_SIZE];
                    ctx.read_bytes(values_data_ptr as usize, &mut tag)
                        .map_err(RuntimeError::from)?;
                    tags.push(tag);
                }
            }
            TagSourceMode::AllUObjectsOfClass { .. } => unreachable!("handled above"),
        }
        Ok(tags)
    }

    /// Count tags currently at the target value via per-tag
    /// `GetGameProgressValue` calls. Returns `(current_unlocked, total)`.
    /// Skips zero-FName placeholders (null Values entries) — those are
    /// neither counted nor totaled.
    ///
    /// Each `GetGameProgressValue` is a UFunction (game-thread only). Currently
    /// unused: read()/status_text() were de-engined (no auto-sweep engine calls;
    /// the inline-detour executor hangs on this build). Retained for the on-demand
    /// "X / Y unlocked" refresh once the HW-breakpoint executor lands.
    #[allow(dead_code)]
    fn count_progress_tags(
        &self,
        ctx: &dyn Ctx,
        source: &crate::signature::TagSourceSpec,
        call: &crate::signature::SetCallSpec,
        value: u8,
        _cached_asset_addr: usize,
    ) -> RuntimeResult<(u32, u32)> {
        let tags = self.extract_progress_tags(ctx, source)?;
        if tags.is_empty() {
            return Ok((0, 0));
        }

        let (world_ctx_addr, _) = ctx
            .find_uobject(
                &call.world_context_class,
                &call.world_context_predicate.to_core(),
            )
            .map_err(RuntimeError::from)?
            .ok_or_else(|| RuntimeError::SignatureInvalid {
                feature: self.id().to_string(),
                reason: format!(
                    "set_progress_tags: no live world-context {} matching {:?}",
                    call.world_context_class, call.world_context_predicate
                ),
            })?;
        let (statics_addr, statics_class) = ctx
            .find_uobject(&call.statics_class, &openforge_core::Predicate::Any)
            .map_err(RuntimeError::from)?
            .ok_or_else(|| RuntimeError::SignatureInvalid {
                feature: self.id().to_string(),
                reason: format!("set_progress_tags: CDO of {} not found", call.statics_class),
            })?;

        let mut current = 0u32;
        let mut total = 0u32;
        for tag in &tags {
            if tag.iter().all(|b| *b == 0) {
                continue;
            }
            total += 1;
            let mut params = vec![0u8; ue5::SPT_GET_PARMS_SIZE];
            params[ue5::SPT_PARM_WORLDCTX..ue5::SPT_PARM_WORLDCTX + 8]
                .copy_from_slice(&world_ctx_addr.to_le_bytes());
            params[ue5::SPT_PARM_TAG..ue5::SPT_PARM_TAG + ue5::SPT_FNAME_SIZE].copy_from_slice(tag);
            let ret = ctx
                .call_ufunction(statics_addr, statics_class, "GetGameProgressValue", params)
                .map_err(RuntimeError::from)?
                .ok_or_else(|| RuntimeError::SignatureInvalid {
                    feature: self.id().to_string(),
                    reason: "GetGameProgressValue not found on statics".into(),
                })?;
            if ret.len() >= ue5::SPT_GET_PARMS_SIZE && ret[ue5::SPT_PARM_VALUE] == value {
                current += 1;
            }
        }
        Ok((current, total))
    }

    /// Execute the SetProgressTags grant: walk the data-asset's TArray,
    /// extract registered `FGameplayTag`s, then call the configured
    /// static UFunction (`SetGameProgressValue`) once per tag with `value`.
    /// `cached_asset_addr` is unused — we re-find the asset to defend
    /// against game-restart address shift; `extract_progress_tags` does the
    /// re-find.
    fn write_set_progress_tags(
        &self,
        ctx: &dyn Ctx,
        source: &crate::signature::TagSourceSpec,
        call: &crate::signature::SetCallSpec,
        value: u8,
        _cached_asset_addr: usize,
    ) -> RuntimeResult<()> {
        let tags = self.extract_progress_tags(ctx, source)?;
        if tags.is_empty() {
            tracing::warn!(
                feature = self.id(),
                "set_progress_tags: empty TArray — nothing to grant"
            );
            return Ok(());
        }

        let (world_ctx_addr, _) = ctx
            .find_uobject(
                &call.world_context_class,
                &call.world_context_predicate.to_core(),
            )
            .map_err(RuntimeError::from)?
            .ok_or_else(|| RuntimeError::SignatureInvalid {
                feature: self.id().to_string(),
                reason: format!(
                    "set_progress_tags: no live world-context {} matching {:?}",
                    call.world_context_class, call.world_context_predicate
                ),
            })?;
        let (statics_addr, statics_class) = ctx
            .find_uobject(&call.statics_class, &openforge_core::Predicate::Any)
            .map_err(RuntimeError::from)?
            .ok_or_else(|| RuntimeError::SignatureInvalid {
                feature: self.id().to_string(),
                reason: format!("set_progress_tags: CDO of {} not found", call.statics_class),
            })?;

        let mut granted = 0usize;
        let mut unchanged = 0usize;
        let mut skipped = 0usize;
        for tag in &tags {
            if tag.iter().all(|b| *b == 0) {
                skipped += 1;
                continue;
            }
            let mut params = vec![0u8; ue5::SPT_SET_PARMS_SIZE];
            params[ue5::SPT_PARM_WORLDCTX..ue5::SPT_PARM_WORLDCTX + 8]
                .copy_from_slice(&world_ctx_addr.to_le_bytes());
            params[ue5::SPT_PARM_TAG..ue5::SPT_PARM_TAG + ue5::SPT_FNAME_SIZE].copy_from_slice(tag);
            params[ue5::SPT_PARM_VALUE] = value;
            // bOnlyIfHigher (+0x11), ChangeSourceIdentifier (+0x18, FString=16),
            // Instigator (+0x28, UObject*=8), ReturnValue (+0x30) all stay
            // zero. Engine fills ReturnValue.
            let ret = ctx
                .call_ufunction(statics_addr, statics_class, &call.function, params)
                .map_err(RuntimeError::from)?
                .ok_or_else(|| RuntimeError::SignatureInvalid {
                    feature: self.id().to_string(),
                    reason: format!(
                        "set_progress_tags: UFunction `{}` not found on {}",
                        call.function, call.statics_class
                    ),
                })?;
            if ret.len() >= ue5::SPT_SET_PARMS_SIZE && ret[0x30] != 0 {
                granted += 1;
            } else {
                unchanged += 1;
            }
        }
        tracing::info!(
            feature = self.id(),
            granted,
            unchanged,
            skipped,
            total = tags.len(),
            value,
            "set_progress_tags fired"
        );
        Ok(())
    }

    /// Execute a `CallInstanceUFunction` write: walk the reflection deref
    /// chain to the final pointer SLOT, dereference it to get the live
    /// target object, read its UClass from the UObject header, and invoke
    /// `function_name` with `params` via `call_ufunction`. Used by Fly
    /// Mode: chain ends at `CharacterMovement` (an ObjectProperty), the
    /// slot's pointer is the live `DinnerCharacterMovementComponent`,
    /// and the call is `SetMovementMode(NewMovementMode, NewCustomMode)`.
    fn write_call_instance_ufunction(
        &self,
        ctx: &dyn Ctx,
        function_name: &str,
        params: Vec<u8>,
    ) -> RuntimeResult<()> {
        // Validate that we have a reflection spec with a non-empty deref
        // chain. `validate()` already enforces this; the runtime panic-style
        // expect() here documents the invariant without adding a fallback.
        let _ref_spec = self
            .spec
            .reflection
            .as_ref()
            .expect("validate() guarantees call_instance_ufunction has a [reflection] block");

        // Ensure the primary cache entry is fresh (heals across world
        // transitions). Returns the PawnPrivate (or equivalent primary)
        // slot address.
        let primary_addr = self.ensure_reflection_fresh(ctx)?;

        let chain: Vec<DerefStep> = {
            let guard = self.reflection_cache.lock();
            guard
                .as_ref()
                .expect("ensure_reflection_fresh populates the cache")
                .derefs
                .clone()
        };
        debug_assert!(
            !chain.is_empty(),
            "validate() guarantees the chain is non-empty"
        );

        let target_slot_addr = self.resolve_deref_addr(ctx, primary_addr, &chain)?;
        // One extra deref: the chain stops at the slot holding the target
        // object's pointer (the FINAL hop's resolved property is an
        // ObjectProperty for CallInstanceUFunction, not a value-type field).
        // Read the slot to get the live call target.
        let target_obj = read_pointer(ctx, target_slot_addr).map_err(RuntimeError::from)?;
        if target_obj == 0 {
            return Err(RuntimeError::SignatureInvalid {
                feature: self.id().to_string(),
                reason: format!(
                    "call_instance_ufunction: target pointer slot at 0x{target_slot_addr:X} \
                     is null — the live component isn't attached yet (typical: player in a \
                     vehicle, mid level transition, or no pawn possessed)"
                ),
            });
        }
        let class_addr = read_pointer(ctx, target_obj.saturating_add(ctx.uobject_class_offset()))
            .map_err(RuntimeError::from)? as u64;

        let params_len = params.len();
        let ret = ctx
            .call_ufunction(target_obj as u64, class_addr, function_name, params)
            .map_err(RuntimeError::from)?;
        if ret.is_none() {
            return Err(RuntimeError::SignatureInvalid {
                feature: self.id().to_string(),
                reason: format!(
                    "call_instance_ufunction: UFunction `{function_name}` not found on \
                     target object's class (target_obj=0x{target_obj:X}, \
                     class_addr=0x{class_addr:X})"
                ),
            });
        }
        tracing::info!(
            feature = self.id(),
            function = function_name,
            target = format!("0x{target_obj:X}"),
            params_len,
            "call_instance_ufunction fired"
        );
        Ok(())
    }

    /// Execute one freeze-for-matching tick: walk every live UObject of
    /// `class_path`, apply include/exclude FQN filters host-side, then write
    /// `payload` at each `field_offset` on each surviving match.
    ///
    /// Writes are best-effort per-match — a single bad address (e.g. an
    /// object freed between the walk and the write) is logged at debug and
    /// the rest of the matches continue. The freeze loop will retry on the
    /// next tick anyway.
    ///
    /// Before each write, the current bytes at the target address are read
    /// once and stashed in `freeze_originals` so toggle-OFF can restore the
    /// stock value per-instance (the engine's standard `feature.restore`
    /// path can only restore a single primary address — useless when we've
    /// stamped 30 goons).
    #[allow(clippy::too_many_arguments)]
    #[allow(clippy::too_many_arguments)]
    fn write_freeze_for_matching(
        &self,
        ctx: &dyn Ctx,
        class_path: &str,
        class_name_substrings: &[String],
        field_offsets: &[i64],
        field_property: Option<&str>,
        payload: &[u8],
        max_results: u32,
        include_fqn_contains: &[String],
        exclude_fqn_contains: &[String],
    ) -> RuntimeResult<()> {
        let (matches, _truncated) = if !class_name_substrings.is_empty() {
            ctx.find_by_class_substring(class_name_substrings, max_results)
                .map_err(RuntimeError::from)?
        } else {
            ctx.find_all_uobjects(class_path, &openforge_core::Predicate::Any, max_results)
                .map_err(RuntimeError::from)?
        };
        if matches.is_empty() {
            return Ok(());
        }
        // When `field_property` is set, the write offset is resolved by
        // reflection off each match's UClass (no baked offset). Most matches
        // share one class, so cache the last resolved (class -> offset) pair.
        let mut last_class: u64 = 0;
        let mut last_offset: u32 = 0;
        let mut hits = 0usize;
        let mut writes = 0usize;
        for m in &matches {
            // Lowercase once per match so substring tests are cheap.
            let fqn_lc = m.fqn.to_ascii_lowercase();
            if !include_fqn_contains.is_empty()
                && !include_fqn_contains
                    .iter()
                    .all(|n| fqn_lc.contains(&n.to_ascii_lowercase()))
            {
                continue;
            }
            if exclude_fqn_contains
                .iter()
                .any(|n| fqn_lc.contains(&n.to_ascii_lowercase()))
            {
                continue;
            }
            hits += 1;
            let base = m.obj_addr as usize;
            // Effective offsets for this match: a single reflection-resolved
            // property offset, or the raw `field_offsets` list.
            let resolved_offsets: Vec<i64> = if let Some(prop) = field_property {
                let offset = if m.class_addr == last_class && last_class != 0 {
                    last_offset
                } else {
                    let resolved = ctx
                        .resolve_property(m.class_addr, prop)
                        .map_err(RuntimeError::from)?
                        .ok_or_else(|| RuntimeError::SignatureInvalid {
                            feature: self.id().to_string(),
                            reason: format!(
                                "freeze_for_matching: property `{prop}` not on class chain \
                                 of a matched `{class_path}` instance"
                            ),
                        })?;
                    last_class = m.class_addr;
                    last_offset = resolved.offset;
                    resolved.offset
                };
                vec![offset as i64]
            } else {
                field_offsets.to_vec()
            };
            for off in &resolved_offsets {
                let addr = (base as i64).wrapping_add(*off) as usize;
                // Capture pre-stamp bytes the first time we touch this
                // address. Best-effort: a read failure here just means we
                // can't restore that one slot on toggle-OFF; we still try
                // the write.
                {
                    let mut originals = self.freeze_originals.lock();
                    if let std::collections::hash_map::Entry::Vacant(slot) = originals.entry(addr) {
                        let mut buf = vec![0u8; payload.len()];
                        match ctx.read_bytes(addr, &mut buf) {
                            Ok(()) => {
                                slot.insert(buf);
                            }
                            Err(e) => {
                                tracing::debug!(
                                    feature = self.id(),
                                    addr = format!("0x{addr:X}"),
                                    error = %e,
                                    "freeze_for_matching: original-snapshot read failed"
                                );
                            }
                        }
                    }
                }
                if let Err(e) = ctx.write_bytes(addr, payload) {
                    tracing::debug!(
                        feature = self.id(),
                        addr = format!("0x{addr:X}"),
                        error = %e,
                        "freeze_for_matching: write failed (skipping)"
                    );
                } else {
                    writes += 1;
                }
            }
        }
        let class_label = if !class_name_substrings.is_empty() {
            class_name_substrings.join(",")
        } else {
            class_path.to_string()
        };
        tracing::debug!(
            feature = self.id(),
            class = class_label,
            scanned = matches.len(),
            hits,
            writes,
            "freeze_for_matching tick"
        );
        Ok(())
    }

    /// Execute one tick of the dance/taunt loop. Walks every live NPC
    /// matching the class filter, computes its distance to the player's
    /// pawn, and (for in-LOD candidates) calls `PlayAnimMontage` with the
    /// next montage in the per-NPC rotation.
    ///
    /// On the first call, resolves every `montage_names` entry via
    /// `find_uobject(class_path="AnimMontage", ..)` and caches the
    /// addresses for the rest of the session.
    #[allow(clippy::too_many_arguments)]
    fn write_play_anim_montage_for_matching(
        &self,
        ctx: &dyn Ctx,
        class_path: &str,
        class_name_substrings: &[String],
        montage_names: &[String],
        max_results: u32,
        max_distance_u: f64,
        include_fqn_contains: &[String],
        exclude_fqn_contains: &[String],
        play_rate: f32,
        player_state_class: &str,
        player_pawn_property: &str,
    ) -> RuntimeResult<()> {
        // 1. Resolve montage addresses (lazy; retry any unresolved slots
        //    next tick).
        let montage_addrs: Vec<u64> = {
            let mut guard = self.montage_cache.lock();
            if guard.is_none() {
                *guard = Some(vec![0u64; montage_names.len()]);
            }
            let cache = guard.as_mut().unwrap();
            for (i, name) in montage_names.iter().enumerate() {
                if cache[i] == 0 {
                    let pred = openforge_core::Predicate::Exact(name.clone());
                    if let Ok(Some((addr, _class))) = ctx.find_uobject("AnimMontage", &pred) {
                        cache[i] = addr;
                    }
                }
            }
            cache.clone()
        };
        let resolved: Vec<u64> = montage_addrs.iter().copied().filter(|a| *a != 0).collect();
        if resolved.is_empty() {
            tracing::warn!(
                feature = self.id(),
                "play_anim_montage_for_matching: no montages resolved yet — \
                 will retry next tick"
            );
            return Ok(());
        }

        // 2. Find the player pawn + its world location. The player-state
        //    is a known stable class; we use `Contains("/PersistentLevel/")`
        //    to skip the CDO.
        let live_pred = openforge_core::Predicate::Contains("/PersistentLevel/".to_string());
        let (ps_addr, ps_class) = match ctx.find_uobject(player_state_class, &live_pred)? {
            Some(pair) => pair,
            None => {
                tracing::debug!(
                    feature = self.id(),
                    "play_anim_montage_for_matching: no live `{player_state_class}` yet (player not spawned?)"
                );
                return Ok(());
            }
        };
        let pawn_prop = match ctx.resolve_property(ps_class, player_pawn_property)? {
            Some(p) => p,
            None => {
                tracing::warn!(
                    feature = self.id(),
                    "play_anim_montage_for_matching: `{player_pawn_property}` not on \
                     player-state class chain"
                );
                return Ok(());
            }
        };
        let pawn_slot_addr = (ps_addr as usize).wrapping_add(pawn_prop.offset as usize);
        let mut pawn_addr_bytes = [0u8; 8];
        ctx.read_bytes(pawn_slot_addr, &mut pawn_addr_bytes)
            .map_err(RuntimeError::from)?;
        let player_pawn = u64::from_le_bytes(pawn_addr_bytes);
        if player_pawn == 0 {
            tracing::debug!(
                feature = self.id(),
                "play_anim_montage_for_matching: player_pawn slot is null"
            );
            return Ok(());
        }
        // Pawn's class is at obj+0x10 (UObject::ClassPrivate).
        let pawn_class = {
            let mut buf = [0u8; 8];
            ctx.read_bytes((player_pawn as usize).wrapping_add(0x10), &mut buf)
                .map_err(RuntimeError::from)?;
            u64::from_le_bytes(buf)
        };
        let player_loc = get_actor_location(ctx, player_pawn, pawn_class)?;

        // 3. Walk NPCs.
        let (matches, _truncated) = if !class_name_substrings.is_empty() {
            ctx.find_by_class_substring(class_name_substrings, max_results)
                .map_err(RuntimeError::from)?
        } else {
            ctx.find_all_uobjects(class_path, &openforge_core::Predicate::Any, max_results)
                .map_err(RuntimeError::from)?
        };
        if matches.is_empty() {
            return Ok(());
        }

        let tick = self
            .montage_tick
            .fetch_add(1, std::sync::atomic::Ordering::Relaxed);

        let mut filtered = 0usize;
        let mut out_of_range = 0usize;
        let mut hits = 0usize;
        for (idx, m) in matches.iter().enumerate() {
            let fqn_lc = m.fqn.to_ascii_lowercase();
            if !include_fqn_contains.is_empty()
                && !include_fqn_contains
                    .iter()
                    .all(|n| fqn_lc.contains(&n.to_ascii_lowercase()))
            {
                continue;
            }
            if exclude_fqn_contains
                .iter()
                .any(|n| fqn_lc.contains(&n.to_ascii_lowercase()))
            {
                continue;
            }
            filtered += 1;
            // Skip the player themselves if they share the class filter.
            if m.obj_addr == player_pawn {
                continue;
            }
            // Distance gate. K2_GetActorLocation failures (component not
            // ready) cause the candidate to be silently dropped this tick.
            let npc_loc = match get_actor_location(ctx, m.obj_addr, m.class_addr) {
                Ok(v) => v,
                Err(_) => {
                    out_of_range += 1;
                    continue;
                }
            };
            let dx = npc_loc[0] - player_loc[0];
            let dy = npc_loc[1] - player_loc[1];
            let dz = npc_loc[2] - player_loc[2];
            let dist = (dx * dx + dy * dy + dz * dz).sqrt();
            if dist > max_distance_u {
                out_of_range += 1;
                continue;
            }
            // Pick the per-NPC montage. (tick + idx) so neighbours don't
            // dance in sync.
            let pick = ((tick as usize) + idx) % resolved.len();
            let montage_addr = resolved[pick];
            let mut params = vec![0u8; 24];
            params[0..8].copy_from_slice(&montage_addr.to_le_bytes());
            params[8..12].copy_from_slice(&play_rate.to_le_bytes());
            // [12..20]: StartSectionName = NAME_None (zeroed)
            // [20..24]: ReturnValue float slot (engine fills duration)
            if let Ok(Some(_)) =
                ctx.call_ufunction(m.obj_addr, m.class_addr, "PlayAnimMontage", params)
            {
                hits += 1;
            }
        }
        tracing::debug!(
            feature = self.id(),
            scanned = matches.len(),
            filtered,
            out_of_range,
            hits,
            resolved_montages = resolved.len(),
            "play_anim_montage_for_matching tick"
        );
        Ok(())
    }

    fn write_teleport_to_waypoint(
        &self,
        ctx: &dyn Ctx,
        waypoint_spec: &ReflectionSpec,
    ) -> RuntimeResult<()> {
        // 1. Resolve waypoint coordinates
        let pred = waypoint_spec.predicate.to_core();
        let (waypoint_obj_addr, waypoint_class_addr) = ctx
            .find_uobject(&waypoint_spec.class_path, &pred)
            .map_err(RuntimeError::from)?
            .ok_or_else(|| RuntimeError::SignatureInvalid {
                feature: self.id().to_string(),
                reason: format!(
                    "teleport_to_waypoint: no live UObject of class `{}` (predicate {:?}). \
                     Make sure a waypoint pin is currently set on the map screen.",
                    waypoint_spec.class_path, waypoint_spec.predicate
                ),
            })?;

        let primary_resolved = ctx
            .resolve_property(waypoint_class_addr, &waypoint_spec.property_name)
            .map_err(RuntimeError::from)?
            .ok_or_else(|| RuntimeError::SignatureInvalid {
                feature: self.id().to_string(),
                reason: format!(
                    "teleport_to_waypoint: property `{}` not found on waypoint class `{}` chain",
                    waypoint_spec.property_name, waypoint_spec.class_path
                ),
            })?;

        let mut waypoint_addr =
            (waypoint_obj_addr as usize).saturating_add(primary_resolved.offset as usize);

        let waypoint_derefs: Vec<DerefStep> = waypoint_spec
            .deref
            .iter()
            .map(|d| DerefStep {
                property_name: d.property_name.clone(),
                inner_offset: d.inner_offset,
            })
            .collect();

        if !waypoint_derefs.is_empty() {
            waypoint_addr = self.resolve_deref_addr(ctx, waypoint_addr, &waypoint_derefs)?;
        }

        let mut coords = [0u8; 24];
        ctx.read_bytes(waypoint_addr, &mut coords)
            .map_err(RuntimeError::from)?;

        // 2. Resolve player pawn actor
        let player_primary_addr = self.ensure_reflection_fresh(ctx)?;

        let player_chain_opt: Option<Vec<DerefStep>> = {
            let cache_guard = self.reflection_cache.lock();
            cache_guard
                .as_ref()
                .filter(|c| !c.derefs.is_empty())
                .map(|c| c.derefs.clone())
        };

        let player_actor = if let Some(chain) = player_chain_opt {
            let target_slot_addr = self.resolve_deref_addr(ctx, player_primary_addr, &chain)?;
            read_pointer(ctx, target_slot_addr).map_err(RuntimeError::from)?
        } else {
            read_pointer(ctx, player_primary_addr).map_err(RuntimeError::from)?
        };

        if player_actor == 0 {
            return Err(RuntimeError::SignatureInvalid {
                feature: self.id().to_string(),
                reason: "teleport_to_waypoint: player pawn actor is null (no pawn possessed)"
                    .to_string(),
            });
        }

        let player_class_addr =
            read_pointer(ctx, player_actor.saturating_add(ctx.uobject_class_offset()))
                .map_err(RuntimeError::from)? as u64;

        // 3. Build parameter buffer (FVector DestLocation + FRotator DestRotation)
        let mut params = vec![0u8; 48];
        params[0..24].copy_from_slice(&coords);

        // 4. Call native UFunction K2_TeleportTo on player pawn
        let ret = ctx
            .call_ufunction(
                player_actor as u64,
                player_class_addr,
                "K2_TeleportTo",
                params,
            )
            .map_err(RuntimeError::from)?;

        if ret.is_none() {
            return Err(RuntimeError::SignatureInvalid {
                feature: self.id().to_string(),
                reason: format!(
                    "teleport_to_waypoint: UFunction `K2_TeleportTo` not found on player pawn actor (class_addr=0x{:X})",
                    player_class_addr
                ),
            });
        }

        tracing::info!(
            feature = self.id(),
            waypoint = format!("0x{:X}", waypoint_addr),
            player = format!("0x{:X}", player_actor),
            "teleport_to_waypoint fired successfully"
        );
        Ok(())
    }

    fn module_name(&self) -> &str {
        self.spec
            .locator
            .as_ref()
            .and_then(|l| l.module.as_deref())
            .unwrap_or("")
    }

    fn apply_chain(&self, ctx: &dyn Ctx, mut addr: usize) -> CoreResult<usize> {
        if let Some(chain) = &self.spec.pointer_chain {
            for hop in &chain.hops {
                if hop.deref {
                    addr = read_pointer(ctx, addr)?;
                }
                addr = (addr as i64).wrapping_add(hop.offset) as usize;
            }
        }
        Ok(addr)
    }

    fn resolve_via_heap_scan(&self, ctx: &dyn Ctx, hs: &HeapScanSpec) -> RuntimeResult<usize> {
        // Only u64/i64 needles are currently supported. Promotion of smaller
        // value_types could be added later, but the LEGO-style "max-cap as
        // structural fingerprint" pattern is always 64-bit-wide on Windows
        // x64 because the underlying class fields are.
        if !matches!(hs.value_type, ValueKind::I64 | ValueKind::U64) {
            return Err(RuntimeError::SignatureInvalid {
                feature: self.id().to_string(),
                reason: format!(
                    "heap_scan.value_type must be i64 or u64 (got {:?})",
                    hs.value_type
                ),
            });
        }
        let needle = hs.value as u64;
        let hits = ctx
            .scan_heap_for_u64_labeled(needle, hs.alignment.max(1), self.id())
            .map_err(RuntimeError::from)?;
        if hits.is_empty() {
            return Err(RuntimeError::SignatureInvalid {
                feature: self.id().to_string(),
                reason: format!(
                    "heap_scan found no matches for value 0x{needle:X} — game state may differ from the signature's assumptions"
                ),
            });
        }
        let validators = hs.all_validators();
        let mut survivors: Vec<usize> = Vec::new();
        for &m in &hits {
            let candidate = (m as i64).wrapping_add(hs.field_offset) as usize;
            let mut all_pass = true;
            for v in &validators {
                if !validator_passes(ctx, candidate, v)? {
                    all_pass = false;
                    break;
                }
            }
            if all_pass {
                survivors.push(candidate);
            }
        }
        match survivors.len() {
            0 => Err(RuntimeError::SignatureInvalid {
                feature: self.id().to_string(),
                reason: format!(
                    "heap_scan: {} raw matches but all failed validator; nothing to bind to",
                    hits.len()
                ),
            }),
            1 => {
                tracing::info!(
                    feature = self.id(),
                    addr = format!("0x{:X}", survivors[0]),
                    raw_matches = hits.len(),
                    "heap_scan bound"
                );
                Ok(survivors[0])
            }
            n => {
                let pretty: Vec<String> = survivors.iter().map(|a| format!("0x{a:X}")).collect();
                tracing::warn!(
                    feature = self.id(),
                    candidates = ?pretty,
                    "heap_scan ambiguous"
                );
                Err(RuntimeError::SignatureInvalid {
                    feature: self.id().to_string(),
                    reason: format!(
                        "heap_scan: {n} candidates pass validator at {} — tighten the validator",
                        pretty.join(", ")
                    ),
                })
            }
        }
    }
}

fn validator_passes(ctx: &dyn Ctx, candidate: usize, v: &HeapValidatorSpec) -> RuntimeResult<bool> {
    let probe_addr = (candidate as i64).wrapping_add(v.relative_offset) as usize;
    let size = v.field_type.size();
    let mut buf = vec![0u8; size];
    if ctx.read_bytes(probe_addr, &mut buf).is_err() {
        // Unreadable probe = treat candidate as invalid.
        return Ok(false);
    }
    let value = Value::from_le_bytes(v.field_type, &buf)?.as_f64();
    Ok(band_contains(value, v.min, v.max))
}

/// True iff `value` lies within the optional inclusive `[min, max]` band.
///
/// NaN never satisfies a *bounded* band: a freed / uninitialised heap region
/// read as f32 is full of `0xFF` bytes, which decodes to NaN, and `value < min`
/// / `value > max` are BOTH false for NaN — so a naive band check would let such
/// garbage pass every validator (this is exactly how a `0xFF`-filled region
/// masqueraded as a second God Mode candidate). Reject NaN explicitly whenever
/// any bound is present. With no bound at all the check degrades to "the field
/// was readable", and NaN is allowed through unchanged.
fn band_contains(value: f64, min: Option<f64>, max: Option<f64>) -> bool {
    if (min.is_some() || max.is_some()) && value.is_nan() {
        return false;
    }
    if let Some(min) = min
        && value < min
    {
        return false;
    }
    if let Some(max) = max
        && value > max
    {
        return false;
    }
    true
}

impl Feature for DeclarativeFeature {
    fn id(&self) -> &str {
        &self.spec.meta.feature
    }

    fn display_name(&self) -> &str {
        &self.spec.meta.display_name
    }

    fn tagline(&self) -> Option<&str> {
        self.spec.meta.tagline.as_deref()
    }

    fn description(&self) -> Option<&str> {
        self.spec.meta.description.as_deref()
    }

    fn icon(&self) -> Option<&str> {
        self.spec.meta.icon.as_deref()
    }

    fn icon_color(&self) -> Option<&str> {
        self.spec.meta.icon_color.as_deref()
    }

    fn control(&self) -> Option<&ControlSpec> {
        self.spec.control.as_ref()
    }

    fn engine_action(&self) -> Option<(&str, Option<&str>)> {
        match &self.spec.write {
            WriteSpec::EngineAction {
                action,
                options_action,
            } => Some((action.as_str(), options_action.as_deref())),
            _ => None,
        }
    }

    fn tier(&self) -> &str {
        &self.spec.meta.tier
    }

    fn category(&self) -> &str {
        &self.spec.meta.kind
    }

    fn kind(&self) -> ValueKind {
        self.spec.effective_kind()
    }

    fn range(&self) -> ValueRange {
        if let Some(v) = &self.spec.value {
            ValueRange {
                min: v.min,
                max: v.max,
            }
        } else {
            ValueRange::default()
        }
    }

    fn write_strategy(&self) -> WriteStrategyKind {
        match self.spec.write {
            WriteSpec::OneShot => WriteStrategyKind::OneShot,
            WriteSpec::Freeze { .. } => WriteStrategyKind::Freeze,
            WriteSpec::CodePatch { .. } => WriteStrategyKind::CodePatch,
            // Dispatched by the app, not the runtime write path; classified
            // OneShot so the FE treats it as a one-shot action (the Dropdown
            // control routes activation through invoke_feature_action).
            WriteSpec::EngineAction { .. } => WriteStrategyKind::OneShot,
            // Action button: kind=Bool, write(true) fires the grant once.
            WriteSpec::SetProgressTags { .. } => WriteStrategyKind::OneShot,
            // FE-wise this acts like a code_patch: a Bool switch whose
            // toggle calls `write(true|false)` once per click. Classifying
            // it as `CodePatch` makes the SwitchControl render the
            // checked-reflects-current-value path, which is what we want
            // (the local store mirrors the write after the IPC succeeds).
            WriteSpec::CallInstanceUFunction { .. } => WriteStrategyKind::CodePatch,
            WriteSpec::TeleportToWaypoint { .. } => WriteStrategyKind::OneShot,
            // FreezeForMatching is a freeze loop driven by the host (the
            // existing `spawn_freeze_task` machinery). The FE renders a
            // freeze switch — `frozen` toggle gates the loop start/stop.
            WriteSpec::FreezeForMatching { .. } => WriteStrategyKind::Freeze,
            // PlayAnimMontageForMatching is also a tick-loop strategy
            // (the freeze-task machinery calls write() at interval_ms);
            // classify as Freeze so the FE renders a switch and the
            // host's freeze scheduler picks it up.
            WriteSpec::PlayAnimMontageForMatching { .. } => WriteStrategyKind::Freeze,
        }
    }

    fn supports_probe(&self) -> bool {
        // SetProgressTags reads are expensive (N × GetGameProgressValue
        // UFunction calls per invocation). Skip them in the probe loop;
        // their status_text refreshes on-demand after writes anyway.
        //
        // CallInstanceUFunction toggles fire a UFunction every probe tick
        // would re-call SetMovementMode (or equivalent) on cadence — not
        // safe; the read sweep would silently spam the engine. Skip the
        // probe; the SwitchControl tracks its own toggle state.
        //
        // FreezeForMatching reads are O(N) over GUObjectArray; the freeze
        // loop already pays that cost on cadence. Skipping the probe loop
        // avoids doubling the walk frequency.
        //
        // EngineAction has no readable memory value (it's an app-dispatched
        // action); probing would call its no-op read() pointlessly.
        !matches!(
            self.spec.write,
            WriteSpec::SetProgressTags { .. }
                | WriteSpec::CallInstanceUFunction { .. }
                | WriteSpec::FreezeForMatching { .. }
                | WriteSpec::PlayAnimMontageForMatching { .. }
                | WriteSpec::EngineAction { .. }
        )
    }

    fn freeze_interval_ms(&self) -> u32 {
        match self.spec.write {
            WriteSpec::Freeze { interval_ms, .. } => interval_ms,
            WriteSpec::FreezeForMatching { interval_ms, .. } => interval_ms,
            WriteSpec::PlayAnimMontageForMatching { interval_ms, .. } => interval_ms,
            _ => 250,
        }
    }

    fn freeze_copy_offset(&self) -> Option<i64> {
        match self.spec.write {
            WriteSpec::Freeze {
                freeze_copy_offset, ..
            } => freeze_copy_offset,
            _ => None,
        }
    }

    fn freeze_value(&self) -> Option<f64> {
        match self.spec.write {
            WriteSpec::Freeze { freeze_value, .. } => freeze_value,
            // FreezeForMatching's effective_kind is Bool; the freeze loop
            // ticks the feature with whatever Value the host computed from
            // freeze_value(). Without an override here, the loop would
            // capture `read()` → `Bool(false)` → every write would no-op.
            // Returning 1.0 coerces to `Bool(true)` so each tick proceeds
            // into the bulk-write path. The 1.0 itself never reaches game
            // memory — the f32 constant written to each match is `value`
            // from the spec, not this coerced bool.
            WriteSpec::FreezeForMatching { .. } => Some(1.0),
            // PlayAnimMontageForMatching is also Bool-effective; coerce the
            // freeze loop's tick value to Bool(true) so write() proceeds.
            WriteSpec::PlayAnimMontageForMatching { .. } => Some(1.0),
            _ => None,
        }
    }

    fn snapshot(&self, ctx: &dyn Ctx, addr: usize) -> RuntimeResult<Vec<u8>> {
        // EngineAction binds no memory (resolve() returns a sentinel), so there
        // is nothing to snapshot/restore. Return empty — restore() no-ops on it.
        if matches!(self.spec.write, WriteSpec::EngineAction { .. }) {
            return Ok(Vec::new());
        }
        let size = self.kind().size();
        let companions: Vec<usize> = self
            .reflection_cache
            .lock()
            .as_ref()
            .map(|c| c.companions.clone())
            .unwrap_or_default();
        let total = size * (1 + companions.len());
        let mut buf = vec![0u8; total];
        ctx.read_bytes(addr, &mut buf[..size])
            .map_err(RuntimeError::from)?;
        for (i, comp) in companions.iter().enumerate() {
            let off = size * (1 + i);
            ctx.read_bytes(*comp, &mut buf[off..off + size])
                .map_err(RuntimeError::from)?;
        }
        Ok(buf)
    }

    fn restore(&self, ctx: &dyn Ctx, addr: usize, snapshot: &[u8]) -> RuntimeResult<()> {
        // FreezeForMatching can stamp dozens of addresses per tick (every
        // matching UObject + every field_offset). The single-address
        // snapshot captured at attach time would only restore one of them,
        // so we maintain a per-instance `freeze_originals` map populated
        // opportunistically during write(). On restore, drain the map and
        // write each captured original back. The `addr`/`snapshot` args are
        // ignored for this variant.
        // PlayAnimMontageForMatching has no per-instance writes to undo —
        // montages naturally end. Just reset the per-feature caches so a
        // re-toggle starts clean (rotation index, resolved montages).
        if matches!(
            self.spec.write,
            WriteSpec::PlayAnimMontageForMatching { .. }
        ) {
            *self.montage_cache.lock() = None;
            self.montage_tick
                .store(0, std::sync::atomic::Ordering::Relaxed);
            let _ = (addr, snapshot);
            return Ok(());
        }
        if matches!(self.spec.write, WriteSpec::FreezeForMatching { .. }) {
            let originals = std::mem::take(&mut *self.freeze_originals.lock());
            let mut restored = 0usize;
            let mut failed = 0usize;
            for (write_addr, bytes) in &originals {
                match ctx.write_bytes(*write_addr, bytes) {
                    Ok(()) => restored += 1,
                    Err(e) => {
                        failed += 1;
                        tracing::debug!(
                            feature = self.id(),
                            addr = format!("0x{write_addr:X}"),
                            error = %e,
                            "freeze_for_matching restore: write failed (object likely despawned)"
                        );
                    }
                }
            }
            tracing::info!(
                feature = self.id(),
                restored,
                failed,
                "freeze_for_matching: per-instance restore complete"
            );
            return Ok(());
        }
        let size = self.kind().size();
        let companions: Vec<usize> = self
            .reflection_cache
            .lock()
            .as_ref()
            .map(|c| c.companions.clone())
            .unwrap_or_default();
        let expected = size * (1 + companions.len());
        if snapshot.len() != expected {
            // Snapshot was captured before companions resolved (or after the
            // cache moved). Fall back to restoring just the primary — partial
            // restore is better than no restore.
            let n = snapshot.len().min(size);
            ctx.write_bytes(addr, &snapshot[..n])
                .map_err(RuntimeError::from)?;
            return Ok(());
        }
        ctx.write_bytes(addr, &snapshot[..size])
            .map_err(RuntimeError::from)?;
        for (i, comp) in companions.iter().enumerate() {
            let off = size * (1 + i);
            ctx.write_bytes(*comp, &snapshot[off..off + size])
                .map_err(RuntimeError::from)?;
        }
        Ok(())
    }

    fn resolve(&self, ctx: &dyn Ctx) -> CoreResult<usize> {
        // EngineAction binds no memory — the target is an app-dispatched
        // engine-thread call. Return a non-zero sentinel so the card shows
        // Ready once attached; write()/read() are guarded no-ops and the
        // dropdown routes activation through invoke_feature_action.
        if matches!(self.spec.write, WriteSpec::EngineAction { .. }) {
            return Ok(1);
        }
        // FreezeForMatching does discovery on every freeze tick (the live
        // enemy roster changes constantly — new spawns, deaths, level
        // streams). Resolve only needs to confirm "at least one match
        // exists right now" so the UI can move the feature to Ready. We do
        // a single FindAllUObjects walk with max_results=1; any hit is
        // sufficient. The returned address is the first match's obj_addr
        // for logging/cache; the freeze loop re-walks each tick.
        if let WriteSpec::FreezeForMatching {
            class_path,
            class_name_substrings,
            ..
        } = &self.spec.write
        {
            let (matches, _truncated) = if !class_name_substrings.is_empty() {
                ctx.find_by_class_substring(class_name_substrings, 1)?
            } else {
                ctx.find_all_uobjects(class_path, &openforge_core::Predicate::Any, 1)?
            };
            let first = matches.first().ok_or_else(|| {
                let target = if !class_name_substrings.is_empty() {
                    format!("any class-name matching {:?}", class_name_substrings)
                } else {
                    format!("class `{class_path}`")
                };
                openforge_core::Error::Custom(format!(
                    "freeze_for_matching: no live instances of {target} yet — \
                     enter a level / hub and retry"
                ))
            })?;
            return Ok(first.obj_addr as usize);
        }
        // PlayAnimMontageForMatching: mirror of FreezeForMatching for
        // resolve-time purposes — confirm at least one NPC exists so the UI
        // shows Ready. Discovery is repeated each tick in `write_play_anim_
        // montage_for_matching` because the live NPC roster changes
        // constantly with LOD streaming.
        if let WriteSpec::PlayAnimMontageForMatching {
            class_path,
            class_name_substrings,
            ..
        } = &self.spec.write
        {
            let (matches, _truncated) = if !class_name_substrings.is_empty() {
                ctx.find_by_class_substring(class_name_substrings, 1)?
            } else {
                ctx.find_all_uobjects(class_path, &openforge_core::Predicate::Any, 1)?
            };
            let first = matches.first().ok_or_else(|| {
                let target = if !class_name_substrings.is_empty() {
                    format!("any class-name matching {:?}", class_name_substrings)
                } else {
                    format!("class `{class_path}`")
                };
                openforge_core::Error::Custom(format!(
                    "play_anim_montage_for_matching: no live instances of {target} yet — \
                     enter a level / hub and retry"
                ))
            })?;
            return Ok(first.obj_addr as usize);
        }
        // SetProgressTags features carry their own asset discovery. The
        // resolved address is the data-asset's UObject pointer — useful as
        // a Pending→Ready signal for the UI (the asset isn't loaded until
        // the player enters a level). Returning anything non-zero satisfies
        // the runtime's "feature resolved" contract; the actual TArray
        // iteration runs lazily inside write().
        if let WriteSpec::SetProgressTags { source, .. } = &self.spec.write {
            // For AllUObjectsOfClass: predicate is ignored; any live
            // instance proves the class is loaded.
            let pred = match &source.mode {
                crate::signature::TagSourceMode::AllUObjectsOfClass { .. } => {
                    openforge_core::Predicate::Any
                }
                _ => source.predicate.to_core(),
            };
            let (asset_addr, _class_addr) = ctx
                .find_uobject(&source.asset_class, &pred)?
                .ok_or_else(|| {
                    openforge_core::Error::Custom(format!(
                        "set_progress_tags: no {} matching {:?} is loaded — \
                         is the player in a level?",
                        source.asset_class, source.predicate
                    ))
                })?;
            return Ok(asset_addr as usize);
        }

        let base = if let Some(ref_spec) = &self.spec.reflection {
            self.resolve_via_reflection(ctx, ref_spec).map_err(|e| {
                openforge_core::Error::Custom(format!("reflection resolve failed: {e}"))
            })?
        } else if let Some(hs) = &self.spec.heap_scan {
            self.resolve_via_heap_scan(ctx, hs).map_err(|e| {
                openforge_core::Error::Custom(format!("heap_scan resolve failed: {e}"))
            })?
        } else {
            let locator = self
                .spec
                .locator
                .as_ref()
                .expect("validate() guarantees one of locator/heap_scan/reflection");
            let pattern = self
                .pattern
                .as_ref()
                .expect("pattern is built whenever locator is present");
            let match_addr = ctx
                .scan_module(self.module_name(), pattern)?
                .ok_or_else(|| openforge_core::Error::PatternNotFound(self.id().to_string()))?;
            let resolve: openforge_core::Resolve = locator.resolve.into();
            resolve.apply(ctx, match_addr)?
        };
        self.apply_chain(ctx, base)
    }

    fn read(&self, ctx: &dyn Ctx, addr: usize) -> RuntimeResult<Value> {
        // EngineAction has no readable value (it's a fire-once app action).
        // Report "off" so the card renders idle; state is not tracked here.
        if matches!(self.spec.write, WriteSpec::EngineAction { .. }) {
            return Ok(Value::Bool(false));
        }
        // SetProgressTags: query the runtime state by calling
        // `GetGameProgressValue` per tag. "Applied" = all tags at target
        // value. ~N round-trips per read; affordable on attach + on-demand
        // refresh, NOT in a tight poll loop. The UI switch reads this as
        // ON-when-fully-unlocked, OFF otherwise; once granted, the user
        // can't "unswitch" — write(false) is intentionally a no-op so
        // unlocks persist.
        // SetProgressTags read does NO engine calls. count_progress_tags drives
        // GetGameProgressValue (a UFunction); UFunction dispatch must run on the
        // game thread, and this read() fires on the automatic attach sweep + every
        // probe — doing engine calls there is both unsafe (no game-thread executor
        // on this build yet — RawDetour hangs) and wrong (an auto-sweep shouldn't
        // execute gameplay code). The unlock switch tracks its own ON/OFF in the
        // FE. Live "X/Y" is computed on demand via the executor once it's wired.
        if matches!(self.spec.write, WriteSpec::SetProgressTags { .. }) {
            return Ok(Value::Bool(false));
        }
        // CallInstanceUFunction toggles are stateless from the trainer's POV
        // — there's no in-memory bool to read back. The MovementMode byte
        // at CMC+0x241 (for fly mode) does reflect engine state, but probing
        // it would require knowing the live CMC's class layout for every
        // such feature. Returning Bool(false) keeps the toggle OFF on
        // initial sweep; the SwitchControl mirrors the user's last click
        // locally via setCodePatch's post-write store update.
        if matches!(
            self.spec.write,
            WriteSpec::CallInstanceUFunction { .. } | WriteSpec::TeleportToWaypoint { .. }
        ) {
            return Ok(Value::Bool(false));
        }
        // FreezeForMatching has no single "current value" — it writes the
        // same constant to N matched UObjects every tick. The FE freeze
        // switch tracks its own state; returning Bool(false) keeps the
        // initial sweep silent and the toggle starts OFF.
        if matches!(self.spec.write, WriteSpec::FreezeForMatching { .. }) {
            return Ok(Value::Bool(false));
        }
        // PlayAnimMontageForMatching: switch tracks its own state — read
        // is a Bool(false) so the initial sweep doesn't flip the toggle on.
        if matches!(
            self.spec.write,
            WriteSpec::PlayAnimMontageForMatching { .. }
        ) {
            return Ok(Value::Bool(false));
        }
        match &self.spec.write {
            WriteSpec::CodePatch {
                original_bytes,
                patched_bytes,
            } => {
                let patched = parse_hex(patched_bytes)?;
                let mut buf = vec![0u8; patched.len().max(parse_hex(original_bytes)?.len())];
                ctx.read_bytes(addr, &mut buf)?;
                // "Applied" = first byte of buffer matches the patched first byte.
                let applied = !patched.is_empty() && buf[0] == patched[0];
                Ok(Value::Bool(applied))
            }
            _ => {
                let kind = self.kind();
                let mut buf = vec![0u8; kind.size()];
                // For reflection-backed features, validate the cached
                // UObject is still live and re-resolve if not. `addr` is
                // ignored when reflection is configured — the fresh primary
                // from the cache (refreshed if needed) takes precedence,
                // because the attach-time `addr` becomes stale on world
                // transitions while the reflection lookup self-heals.
                let primary_addr = if self.spec.reflection.is_some() {
                    self.ensure_reflection_fresh(ctx)?
                } else {
                    addr
                };
                // Reflection-with-deref: `primary_addr` is the root pointer
                // slot, NOT a value slot. Chase the chain to the final value
                // address. Without deref entries, `primary_addr` IS the value slot.
                let read_addr = {
                    let cache_guard = self.reflection_cache.lock();
                    match cache_guard.as_ref() {
                        Some(c) if !c.derefs.is_empty() => {
                            // Clone the chain so we can drop the lock before
                            // the (potentially slow) IPC walk.
                            let chain = c.derefs.clone();
                            drop(cache_guard);
                            self.resolve_deref_addr(ctx, primary_addr, &chain)?
                        }
                        _ => primary_addr,
                    }
                };
                ctx.read_bytes(read_addr, &mut buf)?;
                Value::from_le_bytes(kind, &buf)
            }
        }
    }

    fn write(&self, ctx: &dyn Ctx, addr: usize, v: Value) -> RuntimeResult<()> {
        // EngineAction is never driven through write_feature — the app routes
        // its activation through invoke_feature_action (string payload, engine-
        // thread call). If something does call write() here, fail loudly rather
        // than silently no-op so the wiring bug is obvious.
        if matches!(self.spec.write, WriteSpec::EngineAction { .. }) {
            return Err(openforge_core::Error::Custom(format!(
                "feature `{}` is an engine_action — activate it via invoke_feature_action, \
                 not write_feature",
                self.id()
            ))
            .into());
        }
        // FreezeForMatching: every freeze-task tick lands here with the
        // freeze_value (already coerced to Bool by the spec's effective_kind).
        // Walk the live UObject roster, apply the filters, and write the
        // constant at each match's field_offsets. write(false) is a no-op
        // (toggle OFF stops the freeze task altogether).
        if let WriteSpec::FreezeForMatching {
            class_path,
            class_name_substrings,
            field_offsets,
            field_property,
            value,
            value_bytes,
            max_results,
            include_fqn_contains,
            exclude_fqn_contains,
            ..
        } = &self.spec.write
        {
            let toggle_on = match v {
                Value::Bool(b) => b,
                other => other.as_f64() != 0.0,
            };
            if !toggle_on {
                return Ok(());
            }
            let _ = addr;
            // Decode the write payload up front (validated at signature load,
            // so unwrap is safe here).
            let payload: Vec<u8> = match (value, value_bytes) {
                (Some(v), None) => v.to_le_bytes().to_vec(),
                (None, Some(hex)) => {
                    parse_hex_payload(hex).map_err(|e| RuntimeError::SignatureInvalid {
                        feature: self.id().to_string(),
                        reason: format!("freeze_for_matching: bad value_bytes: {e}"),
                    })?
                }
                _ => unreachable!("validate() ensures exactly one of value/value_bytes"),
            };
            return self.write_freeze_for_matching(
                ctx,
                class_path,
                class_name_substrings,
                field_offsets,
                field_property.as_deref(),
                &payload,
                *max_results,
                include_fqn_contains,
                exclude_fqn_contains,
            );
        }
        // SetProgressTags: action-trigger. write(true) fires the bulk grant,
        // write(false) is intentionally a no-op (player shouldn't lose
        // unlocks). The cached `addr` is the data-asset's UObject pointer
        // from resolve(); the helper re-finds the asset by predicate anyway
        // so a stale `addr` across game restarts is fine.
        if let WriteSpec::SetProgressTags {
            source,
            call,
            value,
            ..
        } = &self.spec.write
        {
            let fire = match v {
                Value::Bool(b) => b,
                other => other.as_f64() != 0.0,
            };
            if !fire {
                return Ok(());
            }
            return self.write_set_progress_tags(ctx, source, call, *value, addr);
        }
        // CallInstanceUFunction: walk the reflection chain to the final
        // pointer slot, deref it to get the live call target (e.g. the
        // DinnerCharacterMovementComponent for fly mode), and invoke the
        // configured UFunction with the on/off payload. An empty payload
        // is a no-op — used to declare "this action can't be reversed".
        if let WriteSpec::CallInstanceUFunction {
            function,
            params_on,
            params_off,
        } = &self.spec.write
        {
            let toggle_on = match v {
                Value::Bool(b) => b,
                other => other.as_f64() != 0.0,
            };
            let payload_hex = if toggle_on { params_on } else { params_off };
            let payload = crate::signature::parse_hex_payload(payload_hex).map_err(|reason| {
                RuntimeError::SignatureInvalid {
                    feature: self.id().to_string(),
                    reason: format!("call_instance_ufunction: {reason}"),
                }
            })?;
            if payload.is_empty() {
                // Empty params_off (toggle-off has no inverse) — silent no-op.
                tracing::info!(
                    feature = self.id(),
                    toggle = toggle_on,
                    "call_instance_ufunction: empty payload, skipping call"
                );
                return Ok(());
            }
            return self.write_call_instance_ufunction(ctx, function, payload);
        }
        // PlayAnimMontageForMatching: every freeze-task tick lands here as
        // write(Bool(true)) (per freeze_value()). Toggle OFF stops the loop;
        // we don't need to actively un-animate anything (montages naturally
        // play out and the AnimInstance returns to its blendspace).
        if let WriteSpec::PlayAnimMontageForMatching {
            class_path,
            class_name_substrings,
            montage_names,
            max_results,
            max_distance_u,
            include_fqn_contains,
            exclude_fqn_contains,
            play_rate,
            player_state_class,
            player_pawn_property,
            ..
        } = &self.spec.write
        {
            let toggle_on = match v {
                Value::Bool(b) => b,
                other => other.as_f64() != 0.0,
            };
            if !toggle_on {
                return Ok(());
            }
            let _ = addr;
            return self.write_play_anim_montage_for_matching(
                ctx,
                class_path,
                class_name_substrings,
                montage_names,
                *max_results,
                *max_distance_u,
                include_fqn_contains,
                exclude_fqn_contains,
                *play_rate,
                player_state_class,
                player_pawn_property,
            );
        }
        if let WriteSpec::TeleportToWaypoint { waypoint } = &self.spec.write {
            let fire = match v {
                Value::Bool(b) => b,
                other => other.as_f64() != 0.0,
            };
            if !fire {
                return Ok(());
            }
            return self.write_teleport_to_waypoint(ctx, waypoint);
        }
        match &self.spec.write {
            WriteSpec::CodePatch {
                original_bytes,
                patched_bytes,
            } => {
                let apply = match v {
                    Value::Bool(b) => b,
                    other => other.as_f64() != 0.0,
                };
                let original = parse_hex(original_bytes)?;
                let patched = parse_hex(patched_bytes)?;
                if apply {
                    // Route through `patch_code` so the IPC backend
                    // (`Ue5Session`) can register the patch with the DLL's
                    // auto-restore map. Native `Target` falls back to a
                    // verify-and-write via the trait's default impl.
                    ctx.patch_code(addr, &original, &patched)?;
                } else {
                    ctx.restore_code(addr, &original)?;
                }
                Ok(())
            }
            _ => {
                let coerced = v.coerce(self.kind())?;
                self.range().check(coerced.as_f64())?;
                let bytes = coerced.to_le_bytes();

                // For reflection-backed features, validate the cached
                // UObject is still live and re-resolve if not. `addr` is
                // ignored when reflection is configured — the fresh primary
                // from the cache (refreshed if needed) takes precedence,
                // because the attach-time `addr` becomes stale on world
                // transitions while the reflection lookup self-heals.
                let primary_addr = if self.spec.reflection.is_some() {
                    self.ensure_reflection_fresh(ctx)?
                } else {
                    addr
                };

                // Reflection cache drives the write dispatch:
                //
                // * No reflection or reflection-without-deref → write at
                //   `primary_addr` directly, then mirror to `also_write`
                //   companions on the same object.
                // * Reflection-with-deref → `primary_addr` is the root pointer
                //   slot (e.g. PlayerState.PawnPrivate). Writing a typed
                //   value there would corrupt the pointer. Skip the
                //   primary write; walk the chain and write to the
                //   real target's address.
                let chain_opt: Option<Vec<DerefStep>> = {
                    let cache_guard = self.reflection_cache.lock();
                    cache_guard
                        .as_ref()
                        .filter(|c| !c.derefs.is_empty())
                        .map(|c| c.derefs.clone())
                };

                if let Some(chain) = chain_opt {
                    let deref_addr = self.resolve_deref_addr(ctx, primary_addr, &chain)?;
                    ctx.write_bytes(deref_addr, &bytes)?;
                    // `also_write` + deref isn't expressible today: no
                    // current feature needs "deref then mirror to peer
                    // offsets on the dereffed class." Validate() catches
                    // the combination at parse time.
                } else {
                    ctx.write_bytes(primary_addr, &bytes)?;
                    let cache_guard = self.reflection_cache.lock();
                    if let Some(c) = cache_guard.as_ref() {
                        for &companion_addr in &c.companions {
                            ctx.write_bytes(companion_addr, &bytes)?;
                        }
                    }
                }
                Ok(())
            }
        }
    }

    fn quick_check(&self, ctx: &dyn Ctx, addr: usize) -> bool {
        // Reflection-backed features point at live UObjects. Those get
        // re-allocated every game launch, so an address cached from a
        // previous process is almost never valid in a new one — even when
        // the module base happens to match. Force a re-resolve.
        if self.spec.reflection.is_some() {
            return false;
        }
        // FreezeForMatching's cached `addr` is just "the first match seen
        // last time" — useful as a Ready signal, useless across sessions
        // (objects get freed/re-allocated). Always re-resolve.
        if matches!(self.spec.write, WriteSpec::FreezeForMatching { .. }) {
            return false;
        }
        // PlayAnimMontageForMatching: cached addr is the first NPC at
        // resolve time. Don't trust it across world transitions; the tick
        // loop re-walks each frame anyway.
        if matches!(
            self.spec.write,
            WriteSpec::PlayAnimMontageForMatching { .. }
        ) {
            return false;
        }
        // Heap-scan features: re-run validators against the cached address.
        // The cached `addr` is the post-`field_offset` candidate, so validators
        // (which use `relative_offset` from that point) apply directly.
        if let Some(hs) = &self.spec.heap_scan {
            for v in hs.all_validators() {
                match validator_passes(ctx, addr, v) {
                    Ok(true) => continue,
                    _ => return false,
                }
            }
            return true;
        }
        // code_patch caches an AOB site. The cache is keyed by module_base, but
        // a no-ASLR title keeps the SAME base across a game UPDATE — so a cache
        // from an older build looks "same process" and would be blindly trusted
        // even though the patch site has shifted (e.g. 007 First Light No Reload:
        // cached 0x141A686A1 from the old build, real site 0x141A62EB1 on the
        // new one → "bytes don't match original"). Verify the cached address
        // still holds `original_bytes` (the pre-patch state present at attach);
        // if not, invalidate so resolve() re-runs the AOB scan and re-finds it.
        if let WriteSpec::CodePatch { original_bytes, .. } = &self.spec.write {
            let Ok(orig) = parse_hex(original_bytes) else {
                return false;
            };
            if orig.is_empty() {
                return false;
            }
            let mut live = vec![0u8; orig.len()];
            return ctx.read_bytes(addr, &mut live).is_ok() && live == orig;
        }
        // Other AOB-pattern features: cached addresses point inside the code
        // section, stable for the process lifetime. Trust the cache.
        true
    }

    fn status_text(&self, ctx: &dyn Ctx, _addr: usize) -> RuntimeResult<Option<String>> {
        // SetProgressTags: compute "X / Y unlocked" + smart completion
        // message. Reuses count_progress_tags from the read() path.
        // SetProgressTags status does NO engine calls (the frontend fires
        // status_text for every feature on attach; count_progress_tags would run
        // cross-thread UFunctions there). Static hint until the game-thread
        // executor (HW-breakpoint rendezvous) is wired and an on-demand refresh
        // can safely compute the live count.
        if let WriteSpec::SetProgressTags { display, .. } = &self.spec.write {
            let msg = match display {
                Some(d) => format!("Click to grant all {} {}.", d.total, d.label),
                None => "Click to grant all.".to_string(),
            };
            return Ok(Some(msg));
        }
        if let WriteSpec::TeleportToWaypoint { waypoint } = &self.spec.write {
            let pred = waypoint.predicate.to_core();
            if let Ok(Some((waypoint_obj_addr, waypoint_class_addr))) =
                ctx.find_uobject(&waypoint.class_path, &pred)
                && let Ok(Some(primary_resolved)) =
                    ctx.resolve_property(waypoint_class_addr, &waypoint.property_name)
            {
                let waypoint_addr =
                    (waypoint_obj_addr as usize).saturating_add(primary_resolved.offset as usize);
                let waypoint_derefs: Vec<DerefStep> = waypoint
                    .deref
                    .iter()
                    .map(|d| DerefStep {
                        property_name: d.property_name.clone(),
                        inner_offset: d.inner_offset,
                    })
                    .collect();
                let resolved = if !waypoint_derefs.is_empty() {
                    self.resolve_deref_addr(ctx, waypoint_addr, &waypoint_derefs)
                } else {
                    Ok(waypoint_addr)
                };
                if let Ok(addr) = resolved {
                    let mut coords = [0u8; 24];
                    if ctx.read_bytes(addr, &mut coords).is_ok() {
                        let x = f64::from_le_bytes(coords[0..8].try_into().unwrap());
                        let y = f64::from_le_bytes(coords[8..16].try_into().unwrap());
                        let z = f64::from_le_bytes(coords[16..24].try_into().unwrap());
                        return Ok(Some(format!(
                            "Active Waypoint: {:.0}, {:.0}, {:.0}",
                            x, y, z
                        )));
                    }
                }
            }
            return Ok(Some("No active waypoint set on map".to_string()));
        }
        Ok(None)
    }
}

/// Call `K2_GetActorLocation` on a UObject and return the FVector3d
/// (UE5 LWC = 3 × f64, world location). The function's ParmsSize is
/// exactly 24 bytes; the engine writes the return into the same buffer.
fn get_actor_location(ctx: &dyn Ctx, obj_addr: u64, class_addr: u64) -> RuntimeResult<[f64; 3]> {
    let params = vec![0u8; 24];
    let ret = ctx
        .call_ufunction(obj_addr, class_addr, "K2_GetActorLocation", params)
        .map_err(RuntimeError::from)?
        .ok_or_else(|| RuntimeError::SignatureInvalid {
            feature: String::new(),
            reason: format!("K2_GetActorLocation not on class chain (obj=0x{obj_addr:X})"),
        })?;
    if ret.len() < 24 {
        return Err(RuntimeError::SignatureInvalid {
            feature: String::new(),
            reason: format!(
                "K2_GetActorLocation returned {} bytes, expected ≥24",
                ret.len()
            ),
        });
    }
    let x = f64::from_le_bytes(ret[0..8].try_into().unwrap());
    let y = f64::from_le_bytes(ret[8..16].try_into().unwrap());
    let z = f64::from_le_bytes(ret[16..24].try_into().unwrap());
    Ok([x, y, z])
}

fn parse_hex(s: &str) -> RuntimeResult<Vec<u8>> {
    let mut out = Vec::new();
    for tok in s.split_whitespace() {
        if tok.len() != 2 || !tok.chars().all(|c| c.is_ascii_hexdigit()) {
            return Err(RuntimeError::SignatureInvalid {
                feature: String::new(),
                reason: format!("bad hex byte {tok:?} in code_patch bytes"),
            });
        }
        out.push(u8::from_str_radix(tok, 16).unwrap());
    }
    Ok(out)
}

#[cfg(test)]
mod band_tests {
    use super::band_contains;

    #[test]
    fn nan_fails_any_bounded_band() {
        // A 0xFF-filled freed region decodes to NaN; it must not satisfy a
        // validator with any bound (the heap_scan false-positive that let a
        // garbage region masquerade as a second God Mode candidate).
        assert!(!band_contains(f64::NAN, Some(1.0), Some(1.0)));
        assert!(!band_contains(f64::NAN, Some(0.0), Some(10000.0)));
        assert!(!band_contains(f64::NAN, Some(99.0), None));
        assert!(!band_contains(f64::NAN, None, Some(101.0)));
    }

    #[test]
    fn in_band_values_pass() {
        assert!(band_contains(1.0, Some(1.0), Some(1.0)));
        assert!(band_contains(150.0, Some(1.0), Some(10000.0)));
        assert!(band_contains(100.0, Some(99.0), Some(101.0)));
        assert!(band_contains(1.5, Some(0.4), Some(3.5)));
    }

    #[test]
    fn out_of_band_values_fail() {
        assert!(!band_contains(0.99, Some(1.0), Some(1.0)));
        assert!(!band_contains(1.01, Some(1.0), Some(1.0)));
        assert!(!band_contains(98.9, Some(99.0), Some(101.0)));
        assert!(!band_contains(3.6, Some(0.4), Some(3.5)));
    }

    #[test]
    fn unbounded_band_is_readability_only() {
        // No bound = "the field was readable" — finite and NaN both pass.
        assert!(band_contains(f64::NAN, None, None));
        assert!(band_contains(12345.0, None, None));
        assert!(band_contains(-9.2e17, None, None));
    }
}
